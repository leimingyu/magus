
#include "ProgressBar.h"

// initialize static members of the ProgressBar class.
const char ProgressBar::barDone[81] = "================================================================================";

